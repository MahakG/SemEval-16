./tunning.sh models/ 0.35
./tunning.sh models/ 0.40
./tunning.sh models/ 0.45
./tunning.sh models/ 0.50
./tunning.sh models/ 0.55
